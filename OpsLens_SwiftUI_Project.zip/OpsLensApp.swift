import SwiftUI

@main
struct OpsLensApp: App {
    var body: some Scene {
        WindowGroup {
            DashboardView()
        }
    }
}