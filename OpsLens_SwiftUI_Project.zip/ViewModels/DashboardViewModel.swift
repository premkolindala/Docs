import Foundation

@MainActor
class DashboardViewModel: ObservableObject {
    @Published var performanceData: [PerformanceMetrics] = []
    @Published var isLoading = false
    @Published var error: Error?

    func loadData() async {
        isLoading = true
        error = nil
        do {
            performanceData = try await AppDynamicsService.shared.fetchPerformanceMetrics()
        } catch {
            self.error = error
        }
        isLoading = false
    }
}