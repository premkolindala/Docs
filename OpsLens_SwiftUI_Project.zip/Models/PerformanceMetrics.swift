import Foundation

struct PerformanceMetrics: Codable, Identifiable {
    let id = UUID()
    let platform: String
    let avgLoginTime: Double
    let avgAccountLoadTime: Double
    let timestamp: String

    enum CodingKeys: String, CodingKey {
        case platform
        case avgLoginTime = "avg(loginTime)"
        case avgAccountLoadTime = "avg(accountLoadTime)"
        case timestamp
    }
}