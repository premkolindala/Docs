import SwiftUI

struct DashboardView: View {
    @StateObject private var viewModel = DashboardViewModel()

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if viewModel.isLoading {
                        ProgressView("Loading metrics...")
                    } else if let error = viewModel.error {
                        Text("Error: \(error.localizedDescription)")
                            .foregroundColor(.red)
                    } else {
                        ForEach(viewModel.performanceData) { metric in
                            VStack(alignment: .leading) {
                                Text("Platform: \(metric.platform)")
                                    .font(.headline)
                                Text("Login Time: \(metric.avgLoginTime, specifier: "%.1f") ms")
                                Text("Account Load Time: \(metric.avgAccountLoadTime, specifier: "%.1f") ms")
                                Text("Timestamp: \(metric.timestamp)")
                            }
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Performance Metrics")
        }
        .task {
            await viewModel.loadData()
        }
    }
}