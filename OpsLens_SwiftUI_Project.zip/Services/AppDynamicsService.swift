import Foundation

class AppDynamicsService {
    static let shared = AppDynamicsService()

    private let baseURL = URL(string: "https://api.appdynamics.com/controller/rest")!
    private let apiToken = "<YOUR_API_TOKEN>" // Secure this in production

    private init() {}

    func fetchPerformanceMetrics() async throws -> [PerformanceMetrics] {
        let endpoint = "analytics/events/query"
        let url = baseURL.appendingPathComponent(endpoint)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload = [
            "query": "SELECT platform, avg(loginTime), avg(accountLoadTime), timestamp FROM mobileMetrics WHERE appName = 'OpsLens' SINCE 1 hour ago"
        ]

        request.httpBody = try JSONSerialization.data(withJSONObject: payload)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResp = response as? HTTPURLResponse, (200..<300).contains(httpResp.statusCode) else {
            throw URLError(.badServerResponse)
        }

        return try JSONDecoder().decode([PerformanceMetrics].self, from: data)
    }
}